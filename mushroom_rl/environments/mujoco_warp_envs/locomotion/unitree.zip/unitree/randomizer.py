"""
Randomizer for legged locomotion.

Works on Go2. WIP for H2.
"""

import math

import torch

from .utils import uniform, bernoulli


class RandomizationParams:
    """
    Domain randomization parameters for legged robots. Inspired by the `new_isaac` branch.
    """

    def __init__(self, **overrides):
        self._values = self._default_values()
        unknown = set(overrides) - set(self._values)
        if unknown:
            raise ValueError(f"unknown randomization parameters: {sorted(unknown)}")
        self._values.update(overrides)

    def __getitem__(self, name):
        return self._values[name]

    def __setitem__(self, name, value):
        if name not in self._values:
            raise ValueError(f"unknown randomization parameter: {name}")
        self._values[name] = value

    def __contains__(self, name):
        return name in self._values

    def as_dict(self):
        return dict(self._values)

    @staticmethod
    def _default_values():
        return dict(
            push_probability=1.0 / 750.0,
            push_interval_range=None,
            push_min_episode_length=50,
            push_max_velocity=1.0,
            ground_friction_factor=5.0 / 9.0,
            # Seconds. Converted to intermediate steps by the Randomizer.
            max_delay=0.02,
            mixed_chance=0.0,
            reset_yaw_range=math.pi,
            # 0.1 matches go2_ppo.py; Davide's Isaac value is 0.05.
            reset_joint_noise=0.1,
            reset_base_velocity=0.2,
            add_trunk_mass=(-2.0, 4.0),
            add_com_displacement=(-0.05, 0.05),
            p_gain_scale=(0.85, 1.15),
            d_gain_scale=(0.85, 1.15),
            torque_limit_factor=0.0,
            add_scaling_factor=(0.0, 0.0),
            add_joint_nominal_position=(0.0, 0.0),
            stay_at_default_percentage=1.0,
            joint_damping=(0.0, 0.3),
            # Absolute range, not a scale: a nonzero spring pulls every joint
            # toward q = 0, not toward the nominal pose. Keep (0, 0) unless
            # the joint zero is the nominal pose.
            joint_stiffness=(0.0, 0.0),
            joint_armature=(0.009, 0.023),
            joint_friction_factor=0.0,
            trunk_mass_factor=0.0,
            trunk_com_factor=0.0,
            joint_damping_factor=0.0,
            joint_stiffness_factor=0.0,
            joint_armature_factor=0.0,
            p_gain_factor=0.0,
            d_gain_factor=0.0,
            motor_strength_factor=0.0,
            position_offset=0.04,
        )


class Randomizer:
    """
    Domain randomization for legged robots. Inspired by the `new_isaac` branch.

    Samples randomized parameters of every world and writes them into the
    per-world model arrays and into pytorch.

    Args:
        n_envs (int): number of worlds;
        views (dict): torch views of the batched model arrays, keyed by the
            mujoco_warp field name. Needed: ``body_mass`` (W, nbody),
            ``body_inertia`` (W, nbody, 3), ``body_ipos`` (W, nbody, 3),
            ``body_subtreemass`` (W, nbody), ``geom_friction`` (W, ngeom, 3),
            ``actuator_gainprm`` (W, nu, 10), ``actuator_biasprm`` (W, nu, 10),
            ``actuator_forcerange`` (W, nu, 2), ``dof_damping`` (W, nv),
            ``dof_armature`` (W, nv), ``dof_frictionloss`` (W, nv),
            ``jnt_stiffness`` (W, njnt). Row 0 must still hold the nominal
            model when the randomizer is built;
        layout (dict): ``trunk_body`` (int), ``trunk_ancestors`` (list of body
            ids whose subtree contains the trunk, trunk included),
            ``foot_geoms`` (long tensor), ``actuators`` (long tensor, all nu
            in order), ``dofs`` (long tensor, dof of each actuator's joint),
            ``joints`` (long tensor, joint of each actuator), ``controlled``
            (long tensor, actuator indices the policy controls);
        default_joint_pos (torch.Tensor): nominal angle of every actuator's
            joint, (nu,);
        action_scale (float): nominal action scaling;
        step_dt (float): duration of one intermediate step, in seconds. Used
            to convert ``max_delay`` into steps;
        params (RandomizationParams, None): the ranges.

    """

    def __init__(
        self,
        n_envs,
        views,
        layout,
        default_joint_pos,
        action_scale,
        step_dt,
        params=None,
    ):
        self._n_envs = n_envs
        self._views = views
        if params is None:
            params = RandomizationParams()
        elif isinstance(params, dict):
            params = RandomizationParams(**params)
        self._params = params
        self._step_dt = float(step_dt)
        dev = views["body_mass"].device
        self._device = dev

        self._trunk = int(layout["trunk_body"])
        self._trunk_ancestors = torch.as_tensor(
            layout["trunk_ancestors"], device=dev, dtype=torch.long
        )
        self._feet = layout["foot_geoms"].to(dev).long()
        self._act = layout["actuators"].to(dev).long()
        self._dofs = layout["dofs"].to(dev).long()
        self._jnts = layout["joints"].to(dev).long()
        self._ctrl = layout["controlled"].to(dev).long()
        nu = len(self._act)
        nc = len(self._ctrl)
        self._nu, self._nc = nu, nc

        # Nominal values, read from world 0 before anything is written.
        v = views
        self._default = dict(
            trunk_mass=v["body_mass"][0, self._trunk].clone(),
            trunk_inertia=v["body_inertia"][0, self._trunk].clone(),
            trunk_com=v["body_ipos"][0, self._trunk].clone(),
            subtreemass=v["body_subtreemass"][0].clone(),
            foot_friction=v["geom_friction"][0, self._feet, 0].clone(),
            kp=v["actuator_gainprm"][0, self._act, 0].clone(),
            kd=-v["actuator_biasprm"][0, self._act, 2].clone(),
            forcerange=v["actuator_forcerange"][0, self._act].clone(),
            damping=v["dof_damping"][0, self._dofs].clone(),
            armature=v["dof_armature"][0, self._dofs].clone(),
            frictionloss=v["dof_frictionloss"][0, self._dofs].clone(),
            stiffness=v["jnt_stiffness"][0, self._jnts].clone(),
            joint_nominal_pos=default_joint_pos.to(dev).clone(),
            action_scale=float(action_scale),
            total_mass=v["body_mass"][0].sum().clone(),
        )
        if not torch.allclose(
            v["actuator_gainprm"][0, self._act, 0],
            -v["actuator_biasprm"][0, self._act, 1],
        ):
            raise ValueError(
                "actuators are not position servos (gainprm[0] != -biasprm[1])"
            )

        # Seen values: what the control law and the observations work from.
        self._seen = dict(
            mass=v["body_mass"][0].sum().expand(n_envs).clone(),
            p_gain=self._default["kp"].expand(n_envs, nu).clone(),
            d_gain=self._default["kd"].expand(n_envs, nu).clone(),
            torque_limit=self._default["forcerange"][:, 1].expand(n_envs, nu).clone(),
            action_scaling_factor=torch.full(
                (n_envs, nc), self._default["action_scale"], device=dev
            ),
            joint_nominal_position=self._default["joint_nominal_pos"]
            .expand(n_envs, nu)
            .clone(),
        )
        # Unseen factors the simulation actually runs on, all 1 by default.
        self._unseen = dict(
            p_gain=torch.ones(n_envs, nu, device=dev),
            d_gain=torch.ones(n_envs, nu, device=dev),
            motor_strength=torch.ones(n_envs, 1, device=dev),
            position_offset=torch.zeros(n_envs, nu, device=dev),
        )
        self._mixed = torch.zeros(n_envs, dtype=torch.bool, device=dev)
        self._n_delay_steps = torch.zeros(n_envs, dtype=torch.long, device=dev)
        self._time_to_push = torch.zeros(n_envs, device=dev)
        self._randomize_push_phase()

    @property
    def params(self):
        return self._params

    @property
    def seen_parameters(self):
        return self._seen

    @property
    def default_parameters(self):
        return self._default

    @property
    def position_offset(self):
        """Encoder miscalibration of every actuator's joint, (W, nu)."""
        return self._unseen["position_offset"]

    @property
    def joint_nominal_pos(self):
        return self._seen["joint_nominal_position"]

    @property
    def scaling_factor(self):
        return self._seen["action_scaling_factor"]

    @property
    def delay_steps(self):
        return self._n_delay_steps

    @property
    def max_delay_steps(self):
        """``max_delay`` in intermediate steps. Read from the params on every
        call, so a curriculum changing ``max_delay`` takes effect."""
        return int(self._params["max_delay"] / self._step_dt + 0.5)

    def resample_startup(self, env_indices):
        """
        Draws what describes the robot itself and stays fixed for the whole
        run: trunk mass, centre of mass and the actuator gains.

        """
        idx = self._idx(env_indices)
        n = len(idx)
        if n == 0:
            return
        dev = self._device
        p = self._params

        # Trunk mass and inertia. The inertia scales with the mass, as in Isaac.
        mass = self._default["trunk_mass"] + uniform(p["add_trunk_mass"], (n,), dev)
        unseen_mass = mass * self._noise_factor(n, "trunk_mass_factor").squeeze(1)
        ratio = unseen_mass / self._default["trunk_mass"]
        v = self._views
        v["body_mass"][idx, self._trunk] = unseen_mass
        v["body_inertia"][idx, self._trunk] = self._default[
            "trunk_inertia"
        ] * ratio.unsqueeze(1)
        delta = unseen_mass - self._default["trunk_mass"]
        v["body_subtreemass"][idx.unsqueeze(1), self._trunk_ancestors.unsqueeze(0)] = (
            self._default["subtreemass"][self._trunk_ancestors].unsqueeze(0)
            + delta.unsqueeze(1)
        )
        # The seen mass is the drawn one; the unseen factor stays hidden.
        self._seen["mass"][idx] = (
            self._default["total_mass"] - self._default["trunk_mass"] + mass
        )

        com = self._default["trunk_com"] + uniform(
            p["add_com_displacement"], (n, 3), dev
        )
        v["body_ipos"][idx, self._trunk] = com * self._noise_factor(
            n, "trunk_com_factor"
        )

        # Gains: seen scale, unseen noise on top.
        self._seen["p_gain"][idx] = self._default["kp"] * uniform(
            p["p_gain_scale"], (n, self._nu), dev
        )
        self._seen["d_gain"][idx] = self._default["kd"] * uniform(
            p["d_gain_scale"], (n, self._nu), dev
        )
        self._unseen["p_gain"][idx] = self._noise_factor(n, "p_gain_factor")
        self._unseen["d_gain"][idx] = self._noise_factor(n, "d_gain_factor")
        self._write_gains(idx)

    def resample_reset(self, env_indices):
        """
        Draws what varies from episode to episode: joint dynamics, torque
        limit, action scaling, encoder offset, motor strength, latency regime
        and ground friction.

        """
        idx = self._idx(env_indices)
        n = len(idx)
        if n == 0:
            return
        dev = self._device
        p = self._params
        v = self._views
        nu, nc = self._nu, self._nc

        # Joint dynamics: absolute range with probability (1 - stay), nominal
        # otherwise, then unseen noise.
        stay = bernoulli(p["stay_at_default_percentage"], n, dev)
        for name, nominal_key, field, sel in (
            ("joint_damping", "damping", "dof_damping", self._dofs),
            ("joint_armature", "armature", "dof_armature", self._dofs),
            ("joint_stiffness", "stiffness", "jnt_stiffness", self._jnts),
        ):
            nominal = self._default[nominal_key]
            drawn = uniform(p[name], (n, nu), dev)
            seen = torch.where(stay.unsqueeze(1), nominal.expand(n, nu), drawn)
            v[field][idx.unsqueeze(1), sel.unsqueeze(0)] = seen * self._noise_factor(
                n, f"{name}_factor"
            )

        hw = p["joint_friction_factor"]
        v["dof_frictionloss"][idx.unsqueeze(1), self._dofs.unsqueeze(0)] = (
            self._default["frictionloss"] * (1.0 + uniform((-hw, hw), (n, nu), dev))
        )

        hw = p["torque_limit_factor"]
        limit = self._default["forcerange"][:, 1] * (
            1.0 + uniform((-hw, hw), (n, nu), dev)
        )
        self._seen["torque_limit"][idx] = limit
        v["actuator_forcerange"][idx.unsqueeze(1), self._act.unsqueeze(0), 0] = -limit
        v["actuator_forcerange"][idx.unsqueeze(1), self._act.unsqueeze(0), 1] = limit

        # Actuation seen by the control law.
        self._seen["action_scaling_factor"][idx] = self._default[
            "action_scale"
        ] + uniform(p["add_scaling_factor"], (n, nc), dev)
        self._seen["joint_nominal_position"][idx] = self._default[
            "joint_nominal_pos"
        ] + uniform(p["add_joint_nominal_position"], (n, nu), dev)
        hw = p["position_offset"]
        self._unseen["position_offset"][idx] = uniform((-hw, hw), (n, nu), dev)
        self._unseen["motor_strength"][idx] = self._noise_factor(
            n, "motor_strength_factor"
        )
        self._write_gains(idx)

        # Latency regime.
        self._mixed[idx] = bernoulli(p["mixed_chance"], n, dev)
        self._n_delay_steps[idx] = torch.randint(
            0, self.max_delay_steps + 1, (n,), device=dev
        )

        # Ground friction: one factor per world, on the foot geoms, whose
        # priority makes them win every foot-floor contact.
        hw = p["ground_friction_factor"]
        factor = 1.0 + uniform((-hw, hw), (n, 1), dev)
        v["geom_friction"][idx.unsqueeze(1), self._feet.unsqueeze(0), 0] = (
            self._default["foot_friction"] * factor
        )

        if p["push_interval_range"] is not None:
            self._time_to_push[idx] = uniform(p["push_interval_range"], (n,), dev)

    def reset_to_nominal(self):
        """
        Puts every world back on the nominal model and control law.
        """
        v, d = self._views, self._default
        W = self._n_envs
        v["body_mass"][:, self._trunk] = d["trunk_mass"]
        v["body_inertia"][:, self._trunk] = d["trunk_inertia"]
        v["body_ipos"][:, self._trunk] = d["trunk_com"]
        v["body_subtreemass"][:, self._trunk_ancestors] = d["subtreemass"][
            self._trunk_ancestors
        ]
        v["geom_friction"][:, self._feet, 0] = d["foot_friction"]
        v["actuator_forcerange"][:, self._act] = d["forcerange"]
        v["dof_damping"][:, self._dofs] = d["damping"]
        v["dof_armature"][:, self._dofs] = d["armature"]
        v["dof_frictionloss"][:, self._dofs] = d["frictionloss"]
        v["jnt_stiffness"][:, self._jnts] = d["stiffness"]

        self._seen["mass"][:] = d["total_mass"]
        self._seen["p_gain"][:] = d["kp"]
        self._seen["d_gain"][:] = d["kd"]
        self._seen["torque_limit"][:] = d["forcerange"][:, 1]
        self._seen["action_scaling_factor"][:] = d["action_scale"]
        self._seen["joint_nominal_position"][:] = d["joint_nominal_pos"]
        for name in ("p_gain", "d_gain", "motor_strength"):
            self._unseen[name][:] = 1.0
        self._unseen["position_offset"][:] = 0.0
        self._mixed[:] = False
        self._n_delay_steps[:] = 0
        self._randomize_push_phase()
        self._write_gains(torch.arange(W, device=self._device))

    def sample_disturbance(self, episode_length, dt):
        """
        Returns the indices of the worlds to push this step and the planar
        velocity to push each with, (k,) and (k, 2).

        """
        p = self._params
        W = self._n_envs
        if p["push_interval_range"] is None:
            do_push = bernoulli(p["push_probability"], W, self._device)
        else:
            self._time_to_push -= dt
            do_push = self._time_to_push <= 0.0
            self._time_to_push = torch.where(
                do_push,
                uniform(p["push_interval_range"], (W,), self._device),
                self._time_to_push,
            )
        do_push &= episode_length > p["push_min_episode_length"]
        idx = torch.nonzero(do_push, as_tuple=True)[0]
        vmax = p["push_max_velocity"]
        return idx, uniform((-vmax, vmax), (len(idx), 2), self._device)

    def sample_latency(self):
        """
        Delay of the next action in intermediate steps, (W,) long.
        No `.any()` test: that would be a host sync at every intermediate
        step. With mixed_chance = 0 (the default) nothing runs at all.
        """
        if self._params["mixed_chance"] > 0.0:
            redrawn = torch.randint(
                0, self.max_delay_steps + 1, (self._n_envs,), device=self._device
            )
            self._n_delay_steps = torch.where(self._mixed, redrawn, self._n_delay_steps)
        return self._n_delay_steps

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _randomize_push_phase(self):
        """Interval mode: start every world's push timer at a random phase, so
        no world is pushed on its first eligible step."""
        interval = self._params["push_interval_range"]
        if interval is not None:
            self._time_to_push[:] = uniform(interval, (self._n_envs,), self._device)
        else:
            self._time_to_push[:] = 0.0

    def _idx(self, env_indices):
        if isinstance(env_indices, torch.Tensor):
            return env_indices.to(self._device).long()
        return torch.as_tensor(env_indices, device=self._device, dtype=torch.long)

    def _noise_factor(self, n, name):
        hw = self._params[name]
        return uniform((1.0 - hw, 1.0 + hw), (n, 1), self._device)

    def _write_gains(self, idx):
        """
        Position servo in MuJoCo: force = kp * ctrl - kp * q - kd * qd, that is
        gainprm[0] = kp, biasprm[1] = -kp, biasprm[2] = -kd. Motor strength
        scales the whole force, so it multiplies all three.

        """
        kp = (
            self._seen["p_gain"][idx]
            * self._unseen["p_gain"][idx]
            * self._unseen["motor_strength"][idx]
        )
        kd = (
            self._seen["d_gain"][idx]
            * self._unseen["d_gain"][idx]
            * self._unseen["motor_strength"][idx]
        )
        rows = idx.unsqueeze(1)
        cols = self._act.unsqueeze(0)
        self._views["actuator_gainprm"][rows, cols, 0] = kp
        self._views["actuator_biasprm"][rows, cols, 1] = -kp
        self._views["actuator_biasprm"][rows, cols, 2] = -kd
